import { useEffect, useRef, useState } from "react";
import { useApp } from "@/lib/app-store";
import { useServerFn } from "@tanstack/react-start";
import { getScanditLicense } from "@/lib/scandit.functions";
import {
  PRODUCTS_BY_CODE,
  matchesAllFilters,
} from "@/lib/products";
import type { Quad } from "@/lib/scandit-ar";
import { ArrowLeft, Camera, Loader2, ListChecks, RotateCcw } from "lucide-react";

type Phase = "live" | "freezing" | "frozen";

type Tracked = { code: string; location: Quad | null };

export function ScanScreen() {
  const { filters, addScanned, resetScanned, setScreen } = useApp();
  const getLicense = useServerFn(getScanditLicense);

  const arContainerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const handleRef = useRef<{ destroy: () => Promise<void> } | null>(null);
  const trackedRef = useRef<Map<string, Quad | null>>(new Map());
  const filtersRef = useRef(filters);
  filtersRef.current = filters;

  const [phase, setPhase] = useState<Phase>("live");
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [matchCount, setMatchCount] = useState(0);
  const [scannedCount, setScannedCount] = useState(0);
  const [restartTick, setRestartTick] = useState(0);

  // Boot Scandit live AR (gives us the live camera + barcode tracking).
  useEffect(() => {
    let cancelled = false;
    setStatus("loading");
    (async () => {
      try {
        const { licenseKey } = await getLicense();
        if (cancelled || !arContainerRef.current) return;
        const { createArView, greenBrush, grayBrush } = await import("@/lib/scandit-ar");
        if (cancelled) return;
        const handle = await createArView(arContainerRef.current, licenseKey, {
          onBarcode: (code, location) => {
            if (!PRODUCTS_BY_CODE.has(code)) return;
            trackedRef.current.set(code, location);
          },
          highlightFor: async (code) => {
            const p = PRODUCTS_BY_CODE.get(code);
            if (!p) return null;
            const ok = matchesAllFilters(p, filtersRef.current);
            return { brush: ok ? greenBrush() : grayBrush() };
          },
        });
        handleRef.current = handle;
        if (!cancelled) setStatus("ready");
      } catch (err) {
        console.error(err);
        if (!cancelled) {
          setErrorMsg(
            err instanceof Error && err.message.includes("Permission")
              ? "Camera access was blocked. Enable it in your browser to scan."
              : "Couldn't start the scanner. Please reload and try again.",
          );
          setStatus("error");
        }
      }
    })();
    return () => {
      cancelled = true;
      handleRef.current?.destroy().catch(() => {});
      handleRef.current = null;
    };
  }, [getLicense, restartTick]);

  async function handleShutter() {
    if (phase !== "live" || status !== "ready") return;
    const container = arContainerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;
    const video = container.querySelector("video") as HTMLVideoElement | null;
    if (!video || !video.videoWidth) return;

    setPhase("freezing");

    // Capture frame onto canvas at native video resolution.
    const w = video.videoWidth;
    const h = video.videoHeight;
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      setPhase("live");
      return;
    }
    ctx.drawImage(video, 0, 0, w, h);

    // Stop Scandit (also releases the camera).
    await handleRef.current?.destroy().catch(() => {});
    handleRef.current = null;

    // Tiny "reading shelf" delay so the spinner is perceptible.
    await new Promise((r) => setTimeout(r, 350));

    // Draw overlays from tracked barcodes.
    let matches = 0;
    let total = 0;
    const codes: string[] = [];
    for (const [code, loc] of trackedRef.current.entries()) {
      const p = PRODUCTS_BY_CODE.get(code);
      if (!p) continue;
      total += 1;
      codes.push(code);
      const ok = matchesAllFilters(p, filtersRef.current);
      if (ok) matches += 1;
      drawQuad(ctx, loc, ok, w, h, p.name);
    }
    codes.forEach((c) => addScanned(c));
    setMatchCount(matches);
    setScannedCount(total);
    setPhase("frozen");
  }

  function handleScanAgain() {
    resetScanned();
    trackedRef.current.clear();
    setMatchCount(0);
    setScannedCount(0);
    setPhase("live");
    setRestartTick((t) => t + 1);
  }

  return (
    <div className="min-h-dvh bg-background text-foreground flex flex-col pb-28">
      <header className="px-4 py-3 border-b border-border flex items-center gap-3">
        {phase === "frozen" ? (
          <button
            onClick={handleScanAgain}
            className="h-9 px-3 rounded-full bg-secondary flex items-center gap-1.5 text-sm font-medium"
          >
            <RotateCcw className="size-4" />
            Scan Again
          </button>
        ) : (
          <button
            onClick={() => setScreen("filters")}
            className="size-10 rounded-full bg-secondary flex items-center justify-center"
            aria-label="Back"
          >
            <ArrowLeft className="size-5" />
          </button>
        )}
        <div className="flex-1 min-w-0">
          <p className="text-xs uppercase tracking-[0.18em] text-primary/80">Shelf scan</p>
          <h1 className="text-base font-semibold leading-tight truncate">
            {filters.length === 0
              ? "No filters · scanning everything"
              : `${filters.length} filter${filters.length === 1 ? "" : "s"} active`}
          </h1>
        </div>
      </header>

      <section className="px-4 pt-4">
        <div className="relative rounded-3xl overflow-hidden border border-border bg-black aspect-[3/4] shadow-xl">
          {/* Live Scandit AR view (camera). Hidden when frozen. */}
          <div
            ref={arContainerRef}
            className="absolute inset-0"
            style={{ visibility: phase === "frozen" ? "hidden" : "visible" }}
          />

          {/* Frozen frame canvas. Hidden while live. */}
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full object-cover"
            style={{ display: phase === "frozen" ? "block" : "none" }}
          />

          {/* Viewfinder rectangle */}
          {phase === "live" && status === "ready" && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="w-3/4 h-3/5 rounded-2xl border-2 border-white/70 shadow-[0_0_0_9999px_rgba(0,0,0,0.25)]" />
            </div>
          )}

          {status === "loading" && phase === "live" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/80 text-white">
              <Camera className="size-10 animate-pulse text-primary" />
              <p className="text-sm text-white/80">Starting camera…</p>
            </div>
          )}

          {status === "error" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-8 text-center bg-black/90 text-white">
              <p className="text-base font-medium">{errorMsg}</p>
              <button
                className="px-4 py-2 rounded-full bg-white/15 backdrop-blur"
                onClick={() => setScreen("filters")}
              >
                Back to filters
              </button>
            </div>
          )}

          {phase === "freezing" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/55 backdrop-blur-sm text-white">
              <Loader2 className="size-10 animate-spin text-primary" />
              <p className="text-sm font-medium">Reading shelf…</p>
            </div>
          )}

          {phase === "frozen" && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-full bg-black/65 backdrop-blur text-white text-xs font-medium whitespace-nowrap">
              {scannedCount === 0
                ? "No barcodes detected"
                : `${matchCount} match${matchCount === 1 ? "" : "es"} · ${scannedCount} scanned`}
            </div>
          )}
        </div>
      </section>

      {/* Bottom action: shutter when live, results pill when frozen */}
      <div className="fixed bottom-0 inset-x-0 p-4 bg-gradient-to-t from-background via-background/95 to-transparent flex justify-center">
        {phase === "frozen" ? (
          <button
            onClick={() => setScreen("results")}
            disabled={scannedCount === 0}
            className="h-14 px-6 rounded-full bg-primary text-primary-foreground font-semibold shadow-xl flex items-center gap-2 active:scale-95 disabled:opacity-40"
          >
            <ListChecks className="size-5" />
            {scannedCount === 0
              ? "Nothing to show — scan again"
              : `${matchCount} item${matchCount === 1 ? "" : "s"} match — see list →`}
          </button>
        ) : (
          <button
            onClick={handleShutter}
            disabled={status !== "ready" || phase !== "live"}
            aria-label="Scan shelf"
            className="size-20 rounded-full bg-white border-4 border-primary flex items-center justify-center shadow-2xl active:scale-95 disabled:opacity-50"
          >
            <span className="text-2xl">📸</span>
          </button>
        )}
        {phase === "live" && (
          <span className="absolute bottom-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
            Scan Shelf
          </span>
        )}
      </div>
    </div>
  );
}

function drawQuad(
  ctx: CanvasRenderingContext2D,
  loc: Quad | null,
  ok: boolean,
  w: number,
  h: number,
  label: string,
) {
  const stroke = ok ? "#10b981" : "#6b7280";
  const fill = ok ? "rgba(16,185,129,0.25)" : "rgba(31,41,55,0.35)";
  ctx.lineWidth = Math.max(4, Math.round(w / 240));
  ctx.strokeStyle = stroke;
  ctx.fillStyle = fill;

  let x: number, y: number, bw: number, bh: number;
  if (loc) {
    const xs = [loc.topLeft.x, loc.topRight.x, loc.bottomRight.x, loc.bottomLeft.x];
    const ys = [loc.topLeft.y, loc.topRight.y, loc.bottomRight.y, loc.bottomLeft.y];
    ctx.beginPath();
    ctx.moveTo(loc.topLeft.x, loc.topLeft.y);
    ctx.lineTo(loc.topRight.x, loc.topRight.y);
    ctx.lineTo(loc.bottomRight.x, loc.bottomRight.y);
    ctx.lineTo(loc.bottomLeft.x, loc.bottomLeft.y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    x = Math.min(...xs);
    y = Math.min(...ys);
    bw = Math.max(...xs) - x;
    bh = Math.max(...ys) - y;
  } else {
    // Fallback rectangle when no location data is available.
    bw = w * 0.3;
    bh = h * 0.15;
    x = (w - bw) / 2;
    y = (h - bh) / 2;
    ctx.fillRect(x, y, bw, bh);
    ctx.strokeRect(x, y, bw, bh);
  }

  if (ok) {
    const fontSize = Math.max(16, Math.round(w / 40));
    ctx.font = `600 ${fontSize}px system-ui, -apple-system, sans-serif`;
    const text = label.length > 28 ? label.slice(0, 27) + "…" : label;
    const padX = 8;
    const padY = 4;
    const tw = ctx.measureText(text).width + padX * 2;
    const th = fontSize + padY * 2;
    const tx = x;
    const ty = Math.max(0, y - th - 4);
    ctx.fillStyle = "#10b981";
    ctx.fillRect(tx, ty, tw, th);
    ctx.fillStyle = "#0a0a0a";
    ctx.fillText(text, tx + padX, ty + fontSize + padY - 2);
  }
}
