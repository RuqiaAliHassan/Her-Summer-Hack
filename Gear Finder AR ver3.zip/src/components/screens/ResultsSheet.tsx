import { useApp } from "@/lib/app-store";
import {
  FILTER_TAGS,
  PRODUCTS_BY_CODE,
  effectivePrice,
  gearScore,
  matchesAllFilters,
  type Product,
} from "@/lib/products";
import { GearScorePie } from "@/components/GearScorePie";
import { ArrowLeft, Footprints, Package, RotateCcw, Shirt } from "lucide-react";

const FILTER_LABELS: Record<string, string> = {
  waterproof: "Waterproof",
  "gore-tex": "Gore-Tex",
  lightweight: "Lightweight",
  breathable: "Breathable",
  grippy: "Grippy sole",
  "trail-running": "Trail running",
  merino: "Merino",
  insulated: "Insulated",
};

function categoryIcon(category: string) {
  if (["trail-shoes", "approach-shoes", "boots"].includes(category)) return Footprints;
  if (["jacket", "midlayer", "baselayer", "pants", "shorts"].includes(category)) return Shirt;
  return Package;
}

function categoryEmoji(category: string): string | null {
  if (category === "socks") return "🧦";
  if (["trail-shoes", "approach-shoes", "boots"].includes(category)) return "👟";
  if (["tshirt", "t-shirt", "baselayer"].includes(category)) return "👕";
  return null;
}

export function ProductImagePlaceholder({
  category,
  className = "",
}: {
  category: string;
  className?: string;
}) {
  const emoji = categoryEmoji(category);
  const Icon = categoryIcon(category);
  return (
    // TODO: replace with real product image
    <div
      className={`aspect-square rounded-lg bg-muted flex flex-col items-center justify-center gap-1 text-muted-foreground ${className}`}
    >
      {emoji ? <span className="text-2xl leading-none">{emoji}</span> : <Icon className="size-6" />}
      <span className="text-[10px] uppercase tracking-wider">Photo coming soon</span>
    </div>
  );
}

function ProductRow({
  product,
  filters,
  dim,
  onTap,
}: {
  product: Product;
  filters: ReturnType<typeof useApp>["filters"];
  dim?: boolean;
  onTap: () => void;
}) {
  const score = gearScore(product, filters);
  const price = effectivePrice(product);
  const discounted = product.discount_pct > 0;
  return (
    <button
      onClick={onTap}
      className={`w-full text-left p-3 rounded-2xl border border-border bg-card active:scale-[0.99] transition ${
        dim ? "opacity-55" : ""
      }`}
    >
      <div className="flex items-baseline gap-2 mb-2">
        <span className="text-xl font-bold text-primary">CHF {price.toFixed(0)}</span>
        {discounted && (
          <span className="text-sm line-through text-muted-foreground">
            CHF {product.price_chf.toFixed(0)}
          </span>
        )}
      </div>
      <div className="flex items-center gap-3">
        {/* TODO: replace with real product image */}
        <ProductImagePlaceholder category={product.category} className="size-14 shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="font-semibold truncate">{product.name}</p>
          <div className="flex items-center gap-2 mt-0.5 text-xs text-muted-foreground">
            <span>{product.weight_g}g</span>
            <span>·</span>
            <span className="truncate">{product.brand}</span>
          </div>
        </div>
        <GearScorePie score={score} />
      </div>
    </button>
  );
}

export function ResultsSheet() {
  const { scannedCodes, filters, toggleFilter, setScreen, setProduct, resetScanned } = useApp();

  const scanned = scannedCodes
    .map((c) => PRODUCTS_BY_CODE.get(c))
    .filter((p): p is Product => Boolean(p));

  const matched = scanned
    .filter((p) => matchesAllFilters(p, filters))
    .sort((a, b) => gearScore(b, filters) - gearScore(a, filters));

  const others = scanned
    .filter((p) => !matchesAllFilters(p, filters))
    .sort((a, b) => gearScore(b, filters) - gearScore(a, filters));

  return (
    <div className="min-h-dvh bg-background text-foreground flex flex-col">
      <header className="sticky top-0 z-10 px-4 py-3 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setScreen("scan")}
            className="size-10 rounded-full bg-secondary flex items-center justify-center"
            aria-label="Back to scan"
          >
            <ArrowLeft className="size-5" />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-base font-semibold leading-tight">Scanned items</h1>
            <p className="text-xs text-muted-foreground">
              {matched.length} match{matched.length === 1 ? "" : "es"} ·{" "}
              {filters.length} filter{filters.length === 1 ? "" : "s"}
            </p>
          </div>
          <button
            onClick={() => {
              resetScanned();
              setScreen("scan");
            }}
            className="h-10 px-3 rounded-full bg-primary text-primary-foreground flex items-center gap-1.5 text-sm font-semibold"
          >
            <RotateCcw className="size-4" />
            Scan Again 🔄
          </button>
        </div>

        <div className="-mx-4 mt-3 px-4 overflow-x-auto">
          <div className="flex gap-2 w-max pb-1">
            {FILTER_TAGS.map((t) => {
              const active = filters.includes(t);
              return (
                <button
                  key={t}
                  onClick={() => toggleFilter(t)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border whitespace-nowrap transition active:scale-95 ${
                    active
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-card text-foreground/80 border-border"
                  }`}
                >
                  {FILTER_LABELS[t]}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-2">
        {matched.length === 0 && others.length === 0 && (
          <p className="text-center text-sm text-muted-foreground py-16">
            No products scanned yet.
          </p>
        )}

        {matched.map((p) => (
          <ProductRow
            key={p.product_code}
            product={p}
            filters={filters}
            onTap={() => {
              setProduct(p);
              setScreen("detail");
            }}
          />
        ))}

        {others.length > 0 && (
          <div className="pt-4 pb-2">
            <p className="text-xs uppercase tracking-widest text-muted-foreground px-1">
              Also scanned — not matching filters
            </p>
          </div>
        )}
        {others.map((p) => (
          <ProductRow
            key={p.product_code}
            product={p}
            filters={filters}
            dim
            onTap={() => {
              setProduct(p);
              setScreen("detail");
            }}
          />
        ))}
      </div>
    </div>
  );
}
