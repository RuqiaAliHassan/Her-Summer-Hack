import { useEffect, useRef, useState } from "react";
import { useApp } from "@/lib/app-store";
import { useServerFn } from "@tanstack/react-start";
import { getScanditLicense } from "@/lib/scandit.functions";
import { PRODUCTS_BY_CODE, sizesForProduct } from "@/lib/products";
import { ArrowLeft, Camera, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";

export function FindOnShelfScreen() {
  const { selectedProduct, setScreen } = useApp();
  const getLicense = useServerFn(getScanditLicense);
  const containerRef = useRef<HTMLDivElement>(null);
  const handleRef = useRef<{ destroy: () => Promise<void> } | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [foundIt, setFoundIt] = useState(false);

  // The target is *any* SKU of the same product_id
  const targetCodes = new Set(
    selectedProduct ? sizesForProduct(selectedProduct.product_id).map((p) => p.product_code) : [],
  );

  useEffect(() => {
    if (!selectedProduct) return;
    let cancelled = false;
    (async () => {
      try {
        const { licenseKey } = await getLicense();
        if (cancelled || !containerRef.current) return;
        const { createArView, pulseBrush, dimBrush, ScanditIconType } = await import(
          "@/lib/scandit-ar"
        );
        if (cancelled) return;
        const handle = await createArView(containerRef.current, licenseKey, {
          onBarcode: (code) => {
            if (targetCodes.has(code)) setFoundIt(true);
          },
          highlightFor: async (code) => {
            if (targetCodes.has(code)) {
              return { brush: pulseBrush(), iconType: ScanditIconType.Checkmark };
            }
            if (!PRODUCTS_BY_CODE.has(code)) return null;
            return { brush: dimBrush(), iconType: null };
          },
          annotationFor: async (code) => {
            if (!targetCodes.has(code)) return null;
            return { title: "This is it! ✓", subtitle: selectedProduct.name };
          },
        });
        handleRef.current = handle;
        if (!cancelled) setStatus("ready");
      } catch (err) {
        console.error(err);
        if (!cancelled) {
          setErrorMsg("Couldn't start the scanner. Please reload and try again.");
          setStatus("error");
        }
      }
    })();
    return () => {
      cancelled = true;
      handleRef.current?.destroy().catch(() => {});
      handleRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!selectedProduct) return null;

  return (
    <div className="fixed inset-0 bg-black text-white">
      <div ref={containerRef} className="absolute inset-0" />

      {status === "loading" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/80">
          <Camera className="size-10 animate-pulse text-primary" />
          <p className="text-sm text-white/80">Starting camera…</p>
        </div>
      )}

      {status === "error" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-8 text-center bg-black/90">
          <p className="text-base font-medium">{errorMsg}</p>
          <Button variant="secondary" onClick={() => setScreen("detail")}>
            Back
          </Button>
        </div>
      )}

      <button
        onClick={() => setScreen("results")}
        className="absolute top-4 left-4 size-11 rounded-full bg-black/55 backdrop-blur flex items-center justify-center"
        aria-label="Back to results"
      >
        <ArrowLeft className="size-5" />
      </button>

      <div className="absolute top-4 left-20 right-4 rounded-2xl bg-primary/95 text-primary-foreground px-4 py-3 shadow-lg">
        <p className="text-sm font-semibold leading-tight truncate">{selectedProduct.name}</p>
        <p className="text-xs opacity-80 flex items-center gap-1 mt-0.5">
          <MapPin className="size-3" />
          Zone {selectedProduct.zone} · {selectedProduct.zone_name} · Aisle {selectedProduct.aisle}
        </p>
      </div>

      {foundIt && (
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 rounded-full bg-primary text-primary-foreground font-semibold shadow-2xl ar-pulse">
          Found it! ✓
        </div>
      )}
    </div>
  );
}
