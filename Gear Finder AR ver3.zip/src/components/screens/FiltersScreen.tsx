import { useApp } from "@/lib/app-store";
import { FILTER_TAGS, zoneHintForFilters } from "@/lib/products";
import storeMap from "@/assets/store-map.png.asset.json";
import { Button } from "@/components/ui/button";
import { ScanLine } from "lucide-react";

const LABELS: Record<string, string> = {
  waterproof: "Waterproof",
  "gore-tex": "Gore-Tex",
  lightweight: "Lightweight",
  breathable: "Breathable",
  grippy: "Grippy sole",
  "trail-running": "Trail running",
  merino: "Merino",
  insulated: "Insulated",
};

export function FiltersScreen() {
  const { filters, toggleFilter, setScreen, resetScanned } = useApp();
  const hint = zoneHintForFilters(filters);

  return (
    <div className="min-h-dvh flex flex-col bg-background text-foreground pb-28">
      <header className="px-5 pt-8 pb-4">
        <p className="text-xs uppercase tracking-[0.2em] text-primary/80">Bergstube · AR Assist</p>
        <h1 className="text-3xl font-semibold mt-1">Find your footwear</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Pick the features that matter, then scan the shoe wall.
        </p>
      </header>

      <section className="px-5">
        <div className="flex flex-wrap gap-2">
          {FILTER_TAGS.map((t) => {
            const active = filters.includes(t);
            return (
              <button
                key={t}
                onClick={() => toggleFilter(t)}
                className={`px-4 py-2.5 rounded-full text-sm font-medium border transition active:scale-95 ${
                  active
                    ? "bg-primary text-primary-foreground border-primary shadow-[0_0_0_3px_rgba(16,185,129,0.18)]"
                    : "bg-card text-foreground/90 border-border hover:border-primary/50"
                }`}
              >
                {LABELS[t]}
              </button>
            );
          })}
        </div>
      </section>

      <section className="px-5 mt-6">
        <div className="rounded-2xl bg-card border border-border overflow-hidden">
          <div className="relative">
            <img src={storeMap.url} alt="Store map" className="w-full h-auto bg-white" />
            {hint && (
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute top-3 left-3 right-3 rounded-xl bg-primary/95 text-primary-foreground px-3 py-2 text-sm font-semibold shadow-lg">
                  Head to Zone {hint.zone} — {hint.zone_name}{" "}
                  <span className="opacity-70 font-normal">· {hint.aisle}</span>
                </div>
              </div>
            )}
          </div>
          <div className="px-4 py-3 text-xs text-muted-foreground">
            {hint
              ? `Aisles ${hint.aisle} · highlighted on the map above.`
              : "Select a filter to see where to go."}
          </div>
        </div>
      </section>

      <div className="flex-1" />

      <div className="fixed bottom-0 inset-x-0 p-4 bg-gradient-to-t from-background via-background/95 to-transparent">
        <Button
          size="lg"
          className="w-full h-14 text-base font-semibold rounded-2xl gap-2"
          onClick={() => {
            resetScanned();
            setScreen("scan");
          }}
        >
          <ScanLine className="size-5" />
          Start Scanning
        </Button>
      </div>
    </div>
  );
}
