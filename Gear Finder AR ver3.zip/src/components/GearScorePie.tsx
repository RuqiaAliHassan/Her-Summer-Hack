import { useMemo } from "react";

type Props = {
  score: number;
  size?: number;
  stroke?: number;
};

export function GearScorePie({ score, size = 44, stroke = 5 }: Props) {
  const { dash, color } = useMemo(() => {
    const r = (size - stroke) / 2;
    const c = 2 * Math.PI * r;
    const pct = Math.max(0, Math.min(100, score)) / 100;
    return {
      dash: `${c * pct} ${c * (1 - pct)}`,
      color:
        score >= 70 ? "#10b981" : score >= 45 ? "#facc15" : "#f87171",
    };
  }, [score, size, stroke]);
  const r = (size - stroke) / 2;

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,0.12)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={dash}
          strokeLinecap="round"
        />
      </svg>
      <span className="absolute text-[10px] font-semibold tabular-nums" style={{ color }}>
        {score}
      </span>
    </div>
  );
}
