import { createServerFn } from "@tanstack/react-start";

export const getScanditLicense = createServerFn({ method: "GET" }).handler(async () => {
  const key = process.env.SCANDIT_LICENSE_KEY;
  if (!key) throw new Error("SCANDIT_LICENSE_KEY not configured");
  return { licenseKey: key };
});
