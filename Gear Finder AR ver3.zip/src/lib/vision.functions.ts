import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";
const MODEL = "google/gemini-3-flash-preview";

async function callGateway(body: unknown): Promise<string> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Missing LOVABLE_API_KEY");
  const res = await fetch(GATEWAY_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": key,
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const txt = await res.text();
    if (res.status === 429) throw new Error("Rate limit hit, please retry shortly.");
    if (res.status === 402) throw new Error("AI credits exhausted.");
    throw new Error(`AI gateway error ${res.status}: ${txt.slice(0, 300)}`);
  }
  const json = (await res.json()) as { choices: { message: { content: string } }[] };
  return json.choices[0]?.message?.content ?? "";
}

function extractJson(text: string): any {
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = fence ? fence[1] : text;
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("No JSON in model response");
  return JSON.parse(raw.slice(start, end + 1));
}

export type ShoeIdentification = {
  name: string;
  brand?: string;
  category: string;
  color?: string;
  style?: string;
  features?: string[];
  confidence: number;
  summary: string;
};

export const identifyShoe = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ imageDataUrl: z.string().min(20) }).parse(input),
  )
  .handler(async ({ data }): Promise<ShoeIdentification> => {
    const content = await callGateway({
      model: MODEL,
      messages: [
        {
          role: "system",
          content:
            "You are an expert outdoor-footwear identifier for a Swiss gear shop. Identify the most prominent shoe in the image and return strict JSON only.",
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Identify the shoe in this photo. Return JSON exactly:
{
  "name": "short specific name (include brand if visible)",
  "brand": "visible brand or empty string",
  "category": "trail-shoes | approach-shoes | boots | running-shoes | casual | other",
  "color": "dominant color(s)",
  "style": "e.g. low-cut trail runner, mid-cut hiking boot, approach shoe",
  "features": ["3-5 visible features e.g. 'aggressive lugs', 'mesh upper', 'gore-tex collar'"],
  "confidence": 0.0-1.0,
  "summary": "one sentence describing the shoe and best use"
}
If no shoe is visible set name "Unknown" and confidence < 0.3. JSON ONLY.`,
            },
            { type: "image_url", image_url: { url: data.imageDataUrl } },
          ],
        },
      ],
    });
    return extractJson(content) as ShoeIdentification;
  });
