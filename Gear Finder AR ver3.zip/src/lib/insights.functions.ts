import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  name: z.string(),
  material: z.string(),
  weight_g: z.number(),
  waterproof_rating_mm: z.number().nullable(),
  temp_rating_c: z.number().nullable(),
  tags: z.array(z.string()),
});

export const getProductInsights = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");

    const prompt = `You are an honest outdoor gear advisor in a Swiss store. Given this product: ${data.name}, ${data.material}, ${data.weight_g}g, waterproof ${data.waterproof_rating_mm ?? "n/a"}mm, temp rating ${data.temp_rating_c ?? "n/a"}°C, tags: ${data.tags.join(", ")}. Give exactly 3 honest insights an experienced hiker would know that the store label doesn't mention. Cover: real-world performance vs marketing claims, fit or sizing quirks, durability or care gotchas. Format: 3 bullet points, max 2 sentences each, no fluff.`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Lovable-API-Key": apiKey,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      console.error("Lovable AI error", res.status, text);
      if (res.status === 429) throw new Error("Rate limit — try again in a moment.");
      if (res.status === 402) throw new Error("AI credits exhausted.");
      throw new Error("AI request failed");
    }

    const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const text = json.choices?.[0]?.message?.content ?? "";
    const bullets = text
      .split("\n")
      .map((l) => l.replace(/^\s*[-•*\d.]+\s*/, "").trim())
      .filter((l) => l.length > 0)
      .slice(0, 3);
    return { bullets };
  });
