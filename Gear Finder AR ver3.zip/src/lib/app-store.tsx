import { createContext, useContext, useState, type ReactNode } from "react";
import type { Product, FilterTag } from "@/lib/products";

export type Screen = "filters" | "scan" | "results" | "detail" | "find";

type Ctx = {
  screen: Screen;
  setScreen: (s: Screen) => void;
  filters: FilterTag[];
  toggleFilter: (t: FilterTag) => void;
  scannedCodes: string[];
  addScanned: (code: string) => void;
  resetScanned: () => void;
  selectedProduct: Product | null;
  setProduct: (p: Product | null) => void;
};

const AppContext = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [screen, setScreen] = useState<Screen>("filters");
  const [filters, setFilters] = useState<FilterTag[]>([]);
  const [scannedCodes, setScannedCodes] = useState<string[]>([]);
  const [selectedProduct, setProduct] = useState<Product | null>(null);

  const value: Ctx = {
    screen,
    setScreen,
    filters,
    toggleFilter: (t) =>
      setFilters((f) => (f.includes(t) ? f.filter((x) => x !== t) : [...f, t])),
    scannedCodes,
    addScanned: (code) =>
      setScannedCodes((s) => (s.includes(code) ? s : [...s, code])),
    resetScanned: () => setScannedCodes([]),
    selectedProduct,
    setProduct,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be inside AppProvider");
  return ctx;
}
