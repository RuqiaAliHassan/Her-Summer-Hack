import { createFileRoute } from "@tanstack/react-router";
import { AppProvider, useApp } from "@/lib/app-store";
import { FiltersScreen } from "@/components/screens/FiltersScreen";
import { ScanScreen } from "@/components/screens/ScanScreen";
import { ResultsSheet } from "@/components/screens/ResultsSheet";
import { DetailScreen } from "@/components/screens/DetailScreen";
import { FindOnShelfScreen } from "@/components/screens/FindOnShelfScreen";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bergstube AR — Find the right gear, fast" },
      {
        name: "description",
        content:
          "Scan outdoor gear in store with AR overlays. Filter by features, see a GearScore, and find your size on the shelf.",
      },
      { property: "og:title", content: "Bergstube AR — Find the right gear, fast" },
      {
        property: "og:description",
        content:
          "Scan outdoor gear in store with AR overlays, GearScore ranking, and shelf-finding.",
      },
    ],
  }),
  component: Index,
});

function Shell() {
  const { screen } = useApp();
  return (
    <div className="min-h-dvh">
      {screen === "filters" && <FiltersScreen />}
      {screen === "scan" && <ScanScreen />}
      {screen === "results" && <ResultsSheet />}
      {screen === "detail" && <DetailScreen />}
      {screen === "find" && <FindOnShelfScreen />}
    </div>
  );
}

function Index() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}
