// Browser-only Scandit MatrixScan AR helper. Don't import server-side.
import {
  BarcodeAr,
  BarcodeArSettings,
  BarcodeArView,
  BarcodeArViewSettings,
  BarcodeArRectangleHighlight,
  BarcodeArInfoAnnotation,
  BarcodeArInfoAnnotationBodyComponent,
  BarcodeArAnnotationTrigger,
  barcodeCaptureLoader,
  Symbology,
} from "@scandit/web-datacapture-barcode";
import {
  Brush,
  Color,
  DataCaptureContext,
  ScanditIconBuilder,
  ScanditIconType,
  ScanditIconShape,
} from "@scandit/web-datacapture-core";

let contextReady: Promise<void> | null = null;

const SDK_VERSION = "8.4.0";
const LIB_LOCATION = `https://cdn.jsdelivr.net/npm/@scandit/web-datacapture-barcode@${SDK_VERSION}/sdc-lib/`;

export async function ensureScanditContext(licenseKey: string) {
  if (!contextReady) {
    contextReady = DataCaptureContext.forLicenseKey(licenseKey, {
      libraryLocation: LIB_LOCATION,
      moduleLoaders: [barcodeCaptureLoader()],
    }).then(() => undefined);
  }
  await contextReady;
}

export type ArHandle = {
  view: BarcodeArView;
  ar: BarcodeAr;
  destroy: () => Promise<void>;
};

export type ArProviders = {
  onBarcode?: (code: string) => void;
  highlightFor: (
    code: string,
  ) => Promise<{ brush: Brush; iconType?: ScanditIconType | null } | null>;
  annotationFor?: (code: string) => Promise<{ title: string; subtitle?: string } | null>;
};

export async function createArView(
  container: HTMLElement,
  licenseKey: string,
  providers: ArProviders,
): Promise<ArHandle> {
  await ensureScanditContext(licenseKey);
  const settings = new BarcodeArSettings();
  settings.enableSymbologies([
    Symbology.QR,
    Symbology.EAN13UPCA,
    Symbology.EAN8,
    Symbology.UPCE,
    Symbology.Code128,
    Symbology.Code39,
    Symbology.DataMatrix,
  ]);

  const ar = await BarcodeAr.forContext(DataCaptureContext.sharedInstance, settings);
  const viewSettings = new BarcodeArViewSettings();
  viewSettings.soundEnabled = false;
  viewSettings.hapticEnabled = true;

  const view = await BarcodeArView.createWithSettings(
    container,
    DataCaptureContext.sharedInstance,
    ar,
    viewSettings,
  );

  const seen = new Set<string>();
  ar.addListener({
    didUpdateSession: (_a, session) => {
      for (const tracked of Object.values(session.addedTrackedBarcodes)) {
        const code = tracked.barcode.data ?? "";
        if (!code || seen.has(code)) continue;
        seen.add(code);
        providers.onBarcode?.(code);
      }
    },
  });

  view.highlightProvider = {
    async highlightForBarcode(barcode, callback) {
      const code = barcode.data ?? "";
      const spec = await providers.highlightFor(code);
      if (!spec) {
        (callback as (v: any) => void)(null);
        return;
      }
      const highlight = BarcodeArRectangleHighlight.create(barcode);
      highlight.brush = spec.brush;
      if (spec.iconType) {
        const icon = await new ScanditIconBuilder()
          .withIcon(spec.iconType)
          .withBackgroundShape(ScanditIconShape.Circle)
          .withBackgroundColor(Color.fromHex("#10b981"))
          .withIconColor(Color.fromHex("#0a0a0a"))
          .build();
        highlight.icon = icon;
      }
      callback(highlight);
    },
  };

  if (providers.annotationFor) {
    view.annotationProvider = {
      async annotationForBarcode(barcode, callback) {
        const code = barcode.data ?? "";
        const spec = await providers.annotationFor!(code);
        if (!spec) {
          (callback as (v: any) => void)(null);
          return;
        }
        const title = BarcodeArInfoAnnotationBodyComponent.create();
        title.text = spec.title;
        const components = [title];
        if (spec.subtitle) {
          const sub = BarcodeArInfoAnnotationBodyComponent.create();
          sub.text = spec.subtitle;
          components.push(sub);
        }
        const annotation = BarcodeArInfoAnnotation.create(barcode);
        annotation.body = components;
        annotation.annotationTrigger = BarcodeArAnnotationTrigger.BarcodeScan;
        callback(annotation);
      },
    };
  }

  await view.start();

  return {
    view,
    ar,
    async destroy() {
      try {
        await view.stop();
      } catch {}
      try {
        view.remove();
      } catch {}
    },
  };
}

export function greenBrush() {
  return new Brush(Color.fromHex("#10b98140"), Color.fromHex("#10b981"), 3);
}
export function grayBrush() {
  return new Brush(Color.fromHex("#1f293780"), Color.fromHex("#6b7280"), 2);
}
export function dimBrush() {
  return new Brush(Color.fromHex("#00000080"), Color.fromHex("#374151"), 1);
}
export function pulseBrush() {
  return new Brush(Color.fromHex("#10b98166"), Color.fromHex("#34d399"), 5);
}

export { ScanditIconType };
