import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  name: z.string(),
  material: z.string(),
  weight_g: z.number(),
  waterproof_rating_mm: z.number().nullable(),
  temp_rating_c: z.number().nullable(),
  tags: z.array(z.string()),
});

export const getProductInsights = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) throw new Error("ANTHROPIC_API_KEY not configured");

    const prompt = `You are an honest outdoor gear advisor in a Swiss store. Given this product: ${data.name}, ${data.material}, ${data.weight_g}g, waterproof ${data.waterproof_rating_mm ?? "n/a"}mm, temp rating ${data.temp_rating_c ?? "n/a"}°C, tags: ${data.tags.join(", ")}. Give exactly 3 honest insights an experienced hiker would know that the store label doesn't mention. Cover: real-world performance vs marketing claims, fit or sizing quirks, durability or care gotchas. Format: 3 bullet points, max 2 sentences each, no fluff.`;

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 350,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      console.error("Anthropic error", res.status, text);
      throw new Error("AI request failed");
    }

    const json = (await res.json()) as { content: { type: string; text: string }[] };
    const text = json.content?.find((c) => c.type === "text")?.text ?? "";
    // parse bullet points
    const bullets = text
      .split("\n")
      .map((l) => l.replace(/^\s*[-•*]\s*/, "").trim())
      .filter((l) => l.length > 0)
      .slice(0, 3);
    return { bullets };
  });
