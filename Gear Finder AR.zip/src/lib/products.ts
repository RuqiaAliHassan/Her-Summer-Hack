import productsRaw from "@/data/products.json";

export type Product = {
  product_code: string;
  product_id: string;
  name: string;
  brand: string;
  category: string;
  color: string;
  size: string;
  price_chf: number;
  discount_pct: number;
  weight_g: number;
  waterproof_rating_mm: number | null;
  temp_rating_c: number | null;
  material: string;
  tags: string[];
  zone: string;
  zone_name: string;
  aisle: string;
  stock_total: number;
  stock_front: number;
  description: string;
};

export const PRODUCTS: Product[] = productsRaw as Product[];

export const PRODUCTS_BY_CODE = new Map<string, Product>(
  PRODUCTS.map((p) => [p.product_code, p]),
);

export const FILTER_TAGS = [
  "waterproof",
  "gore-tex",
  "lightweight",
  "breathable",
  "grippy",
  "trail-running",
  "merino",
  "insulated",
] as const;
export type FilterTag = (typeof FILTER_TAGS)[number];

const TAG_TO_ZONES: Record<string, { zone: string; zone_name: string; aisle: string }> = {};
for (const tag of FILTER_TAGS) {
  const FOOTWEAR = new Set(["trail-shoes", "approach-shoes", "boots", "socks"]);
  const matches = PRODUCTS.filter((p) => p.tags.includes(tag) && FOOTWEAR.has(p.category));
  if (matches.length) {
    // pick most common zone
    const counts = new Map<string, number>();
    for (const m of matches) counts.set(m.zone, (counts.get(m.zone) ?? 0) + 1);
    const topZone = [...counts.entries()].sort((a, b) => b[1] - a[1])[0][0];
    const sample = matches.find((m) => m.zone === topZone)!;
    const aisles = [
      ...new Set(matches.filter((m) => m.zone === topZone).map((m) => m.aisle)),
    ].sort();
    TAG_TO_ZONES[tag] = {
      zone: sample.zone,
      zone_name: sample.zone_name,
      aisle: aisles.length > 1 ? `${aisles[0]}–${aisles[aisles.length - 1]}` : aisles[0],
    };
  }
}

export function zoneHintForFilters(
  filters: FilterTag[],
): { zone: string; zone_name: string; aisle: string } | null {
  if (filters.length === 0) return null;
  // use first selected filter as primary cue
  return TAG_TO_ZONES[filters[0]] ?? null;
}

// --- GearScore ----------------------------------------------------------------

const stats = (() => {
  const weights = PRODUCTS.map((p) => p.weight_g).filter((v) => v > 0);
  const prices = PRODUCTS.map((p) => p.price_chf).filter((v) => v > 0);
  const wps = PRODUCTS.map((p) => p.waterproof_rating_mm ?? 0);
  const temps = PRODUCTS.map((p) => p.temp_rating_c).filter((v): v is number => v !== null);
  return {
    weightMin: Math.min(...weights),
    weightMax: Math.max(...weights),
    priceMin: Math.min(...prices),
    priceMax: Math.max(...prices),
    wpMax: Math.max(...wps, 1),
    tempMin: temps.length ? Math.min(...temps) : 0,
    tempMax: temps.length ? Math.max(...temps) : 1,
  };
})();

function norm(v: number, min: number, max: number) {
  if (max === min) return 0.5;
  return Math.max(0, Math.min(1, (v - min) / (max - min)));
}

export function gearScore(p: Product): number {
  const wpScore = p.waterproof_rating_mm ? norm(p.waterproof_rating_mm, 0, stats.wpMax) : 0.4;
  const weightScore = 1 - norm(p.weight_g, stats.weightMin, stats.weightMax);
  const priceScore = 1 - norm(p.price_chf, stats.priceMin, stats.priceMax);
  const discountScore = Math.min(1, p.discount_pct / 30);
  const tempScore =
    p.temp_rating_c !== null
      ? 1 - norm(p.temp_rating_c, stats.tempMin, stats.tempMax)
      : 0.5;
  const raw =
    wpScore * 0.3 + weightScore * 0.25 + priceScore * 0.2 + discountScore * 0.1 + tempScore * 0.15;
  return Math.round(raw * 100);
}

export function matchesAllFilters(p: Product, filters: FilterTag[]): boolean {
  if (filters.length === 0) return true;
  return filters.every((f) => p.tags.includes(f));
}

// group SKU variants by product_id (the same product in different sizes)
export function sizesForProduct(productId: string): Product[] {
  return PRODUCTS.filter((p) => p.product_id === productId);
}

export function alternativesForCategory(category: string, excludeProductId: string): Product[] {
  const seen = new Set<string>();
  const out: Product[] = [];
  for (const p of PRODUCTS) {
    if (p.category !== category) continue;
    if (p.product_id === excludeProductId) continue;
    if (seen.has(p.product_id)) continue;
    seen.add(p.product_id);
    out.push(p);
    if (out.length >= 2) break;
  }
  return out;
}

export function effectivePrice(p: Product): number {
  if (p.discount_pct > 0) return Math.round(p.price_chf * (1 - p.discount_pct / 100) * 100) / 100;
  return p.price_chf;
}
