import { useEffect, useState } from "react";
import { useApp } from "@/lib/app-store";
import { useServerFn } from "@tanstack/react-start";
import { getProductInsights } from "@/lib/insights.functions";
import {
  alternativesForCategory,
  effectivePrice,
  gearScore,
  sizesForProduct,
} from "@/lib/products";
import { GearScorePie } from "@/components/GearScorePie";
import { Button } from "@/components/ui/button";
import { ArrowLeft, MapPin, Sparkles } from "lucide-react";

export function DetailScreen() {
  const { selectedProduct, setScreen, setProduct } = useApp();
  const getInsights = useServerFn(getProductInsights);
  const [bullets, setBullets] = useState<string[] | null>(null);
  const [aiError, setAiError] = useState(false);

  useEffect(() => {
    if (!selectedProduct) return;
    let cancelled = false;
    setBullets(null);
    setAiError(false);
    getInsights({
      data: {
        name: selectedProduct.name,
        material: selectedProduct.material,
        weight_g: selectedProduct.weight_g,
        waterproof_rating_mm: selectedProduct.waterproof_rating_mm,
        temp_rating_c: selectedProduct.temp_rating_c,
        tags: selectedProduct.tags,
      },
    })
      .then((res) => {
        if (!cancelled) setBullets(res.bullets);
      })
      .catch((e) => {
        console.error(e);
        if (!cancelled) setAiError(true);
      });
    return () => {
      cancelled = true;
    };
  }, [selectedProduct, getInsights]);

  if (!selectedProduct) return null;

  const sizes = sizesForProduct(selectedProduct.product_id);
  const alts = alternativesForCategory(selectedProduct.category, selectedProduct.product_id);
  const score = gearScore(selectedProduct);
  const price = effectivePrice(selectedProduct);

  return (
    <div className="min-h-dvh bg-background text-foreground pb-28">
      <header className="sticky top-0 z-10 px-4 py-3 bg-background/95 backdrop-blur border-b border-border flex items-center gap-3">
        <button
          onClick={() => setScreen("results")}
          className="size-10 rounded-full bg-secondary flex items-center justify-center"
          aria-label="Back"
        >
          <ArrowLeft className="size-5" />
        </button>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground truncate">{selectedProduct.brand}</p>
          <h1 className="text-base font-semibold truncate">{selectedProduct.name}</h1>
        </div>
      </header>

      <section className="px-5 pt-5">
        <p className="text-xs uppercase tracking-widest text-muted-foreground mb-2">
          Available sizes
        </p>
        <div className="flex flex-wrap gap-2">
          {sizes.map((s) => {
            const out = s.stock_total === 0;
            const askStaff = !out && s.stock_front === 0;
            const tone = out
              ? "bg-destructive/20 text-destructive border-destructive/40"
              : askStaff
                ? "bg-amber-500/15 text-amber-300 border-amber-500/40"
                : "bg-primary/15 text-primary border-primary/40";
            const label = out ? "Sold out" : askStaff ? "Ask staff" : `${s.stock_total} in stock`;
            return (
              <div
                key={s.product_code}
                className={`px-3 py-2 rounded-xl border text-sm font-medium ${tone}`}
              >
                <span className="font-semibold mr-1">{s.size}</span>
                <span className="text-xs opacity-80">{label}</span>
              </div>
            );
          })}
        </div>
      </section>

      <section className="px-5 mt-6">
        <div className="rounded-3xl bg-card border border-border p-5 flex items-center gap-5">
          <GearScorePie score={score} size={96} stroke={9} />
          <div className="flex-1">
            <p className="text-xs uppercase tracking-widest text-muted-foreground">GearScore</p>
            <p className="text-3xl font-semibold mt-1">{score}/100</p>
            <p className="text-sm text-muted-foreground mt-1">
              CHF {price.toFixed(0)} · {selectedProduct.weight_g}g · {selectedProduct.material}
            </p>
          </div>
        </div>
      </section>

      <section className="px-5 mt-6">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="size-4 text-primary" />
          <h2 className="text-base font-semibold">What the label doesn't tell you 🔍</h2>
        </div>
        <div className="rounded-2xl bg-card border border-border p-4">
          {!bullets && !aiError && (
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground italic">Asking our gear expert…</p>
              {[0, 1, 2].map((i) => (
                <div key={i} className="space-y-2">
                  <div className="h-3 rounded bg-muted animate-pulse w-11/12" />
                  <div className="h-3 rounded bg-muted animate-pulse w-3/4" />
                </div>
              ))}
            </div>
          )}
          {aiError && (
            <p className="text-sm text-muted-foreground">
              Our gear expert is taking a break — try again later.
            </p>
          )}
          {bullets && (
            <ul className="space-y-3">
              {bullets.map((b, i) => (
                <li key={i} className="flex gap-3 text-sm leading-snug">
                  <span className="size-1.5 rounded-full bg-primary mt-2 shrink-0" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      {alts.length > 0 && (
        <section className="px-5 mt-6">
          <p className="text-xs uppercase tracking-widest text-muted-foreground mb-3">
            Similar in this category
          </p>
          <div className="grid grid-cols-2 gap-3">
            {alts.map((a) => (
              <button
                key={a.product_code}
                onClick={() => setProduct(a)}
                className="text-left p-3 rounded-2xl bg-card border border-border active:scale-95 transition"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-muted-foreground">{a.brand}</span>
                  <GearScorePie score={gearScore(a)} size={32} stroke={4} />
                </div>
                <p className="text-sm font-medium leading-snug line-clamp-2">{a.name}</p>
                <p className="text-xs text-muted-foreground mt-1">CHF {effectivePrice(a).toFixed(0)}</p>
              </button>
            ))}
          </div>
        </section>
      )}

      <div className="fixed bottom-0 inset-x-0 p-4 bg-gradient-to-t from-background via-background/95 to-transparent">
        <Button
          size="lg"
          className="w-full h-14 text-base font-semibold rounded-2xl gap-2"
          onClick={() => setScreen("find")}
        >
          <MapPin className="size-5" />
          Find this on the shelf →
        </Button>
      </div>
    </div>
  );
}
