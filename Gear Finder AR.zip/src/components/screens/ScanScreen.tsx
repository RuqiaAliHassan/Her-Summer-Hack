import { useEffect, useRef, useState } from "react";
import { useApp } from "@/lib/app-store";
import { useServerFn } from "@tanstack/react-start";
import { getScanditLicense } from "@/lib/scandit.functions";
import { identifyShoe, type ShoeIdentification } from "@/lib/vision.functions";
import {
  PRODUCTS,
  PRODUCTS_BY_CODE,
  matchesAllFilters,
  effectivePrice,
  type Product,
} from "@/lib/products";
import { Button } from "@/components/ui/button";
import {
  ArrowLeft,
  Camera,
  ListChecks,
  Sparkles,
  X,
  Loader2,
} from "lucide-react";

const SHOE_CATEGORIES = new Set(["trail-shoes", "approach-shoes", "boots"]);

function nearestProduct(id: ShoeIdentification, filters: string[]): Product | null {
  const pool = PRODUCTS.filter((p) => SHOE_CATEGORIES.has(p.category));
  if (pool.length === 0) return null;
  const idColor = (id.color ?? "").toLowerCase();
  const idBrand = (id.brand ?? "").toLowerCase();
  const idCat = (id.category ?? "").toLowerCase();
  let best: { p: Product; score: number } | null = null;
  for (const p of pool) {
    let score = 0;
    if (idCat && p.category.includes(idCat.replace("-shoes", ""))) score += 3;
    if (idCat.includes("boot") && p.category === "boots") score += 4;
    if (idCat.includes("trail") && p.category === "trail-shoes") score += 4;
    if (idCat.includes("approach") && p.category === "approach-shoes") score += 4;
    if (idBrand && p.brand.toLowerCase() === idBrand) score += 5;
    if (idColor && p.color.toLowerCase().split(/[\s/]/).some((c) => idColor.includes(c)))
      score += 2;
    if (filters.every((f) => p.tags.includes(f))) score += 1;
    if (!best || score > best.score) best = { p, score };
  }
  return best && best.score > 0 ? best.p : null;
}

export function ScanScreen() {
  const { filters, addScanned, scannedCodes, setScreen } = useApp();
  const getLicense = useServerFn(getScanditLicense);
  const identifyFn = useServerFn(identifyShoe);
  const containerRef = useRef<HTMLDivElement>(null);
  const handleRef = useRef<{ destroy: () => Promise<void> } | null>(null);
  const filtersRef = useRef(filters);
  filtersRef.current = filters;
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [identifying, setIdentifying] = useState(false);
  const [identification, setIdentification] = useState<
    { id: ShoeIdentification; match: Product | null } | null
  >(null);

  const matchCount = scannedCodes.filter((c) => {
    const p = PRODUCTS_BY_CODE.get(c);
    return p && matchesAllFilters(p, filters);
  }).length;

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { licenseKey } = await getLicense();
        if (cancelled || !containerRef.current) return;
        const { createArView, greenBrush, grayBrush, ScanditIconType } = await import(
          "@/lib/scandit-ar"
        );
        if (cancelled) return;
        const handle = await createArView(containerRef.current, licenseKey, {
          onBarcode: (code) => {
            if (PRODUCTS_BY_CODE.has(code)) addScanned(code);
          },
          highlightFor: async (code) => {
            const p = PRODUCTS_BY_CODE.get(code);
            if (!p) return null;
            const ok = matchesAllFilters(p, filtersRef.current);
            return ok
              ? { brush: greenBrush(), iconType: ScanditIconType.Checkmark }
              : { brush: grayBrush(), iconType: null };
          },
          annotationFor: async (code) => {
            const p = PRODUCTS_BY_CODE.get(code);
            if (!p) return null;
            const ok = matchesAllFilters(p, filtersRef.current);
            if (!ok) return null;
            return {
              title: p.name,
              subtitle: `CHF ${effectivePrice(p).toFixed(0)} · ${p.weight_g}g`,
            };
          },
        });
        handleRef.current = handle;
        if (!cancelled) setStatus("ready");
      } catch (err) {
        console.error(err);
        if (!cancelled) {
          setErrorMsg(
            err instanceof Error && err.message.includes("Permission")
              ? "Camera access was blocked. Enable it in your browser to scan."
              : "Couldn't start the scanner. Please reload and try again.",
          );
          setStatus("error");
        }
      }
    })();
    return () => {
      cancelled = true;
      handleRef.current?.destroy().catch(() => {});
      handleRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleIdentify() {
    if (identifying || !containerRef.current) return;
    const video = containerRef.current.querySelector("video") as HTMLVideoElement | null;
    if (!video || !video.videoWidth) {
      setIdentification(null);
      return;
    }
    setIdentifying(true);
    try {
      const canvas = document.createElement("canvas");
      const w = Math.min(720, video.videoWidth);
      const scale = w / video.videoWidth;
      canvas.width = w;
      canvas.height = Math.round(video.videoHeight * scale);
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("canvas-unavailable");
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL("image/jpeg", 0.8);
      const id = await identifyFn({ data: { imageDataUrl: dataUrl } });
      const match = nearestProduct(id, filtersRef.current);
      setIdentification({ id, match });
    } catch (err) {
      console.error(err);
      setIdentification({
        id: {
          name: "Couldn't identify",
          category: "other",
          confidence: 0,
          summary: "Try again with the shoe centered in the frame.",
        },
        match: null,
      });
    } finally {
      setIdentifying(false);
    }
  }

  return (
    <div className="min-h-dvh bg-background text-foreground flex flex-col pb-28">
      <header className="px-4 py-3 border-b border-border flex items-center gap-3">
        <button
          onClick={() => setScreen("filters")}
          className="size-10 rounded-full bg-secondary flex items-center justify-center"
          aria-label="Back"
        >
          <ArrowLeft className="size-5" />
        </button>
        <div className="flex-1 min-w-0">
          <p className="text-xs uppercase tracking-[0.18em] text-primary/80">Scan shoes</p>
          <h1 className="text-base font-semibold leading-tight truncate">
            {filters.length === 0
              ? "No filters · scanning everything"
              : `${filters.length} filter${filters.length === 1 ? "" : "s"} active`}
          </h1>
        </div>
        <button
          onClick={() => setScreen("results")}
          disabled={scannedCodes.length === 0}
          className="h-10 px-3 rounded-full bg-secondary flex items-center gap-1.5 text-sm font-medium disabled:opacity-40"
        >
          <ListChecks className="size-4" />
          {scannedCodes.length}
        </button>
      </header>

      <section className="px-4 pt-4">
        <div className="relative rounded-3xl overflow-hidden border border-border bg-black aspect-[3/4] shadow-xl">
          <div ref={containerRef} className="absolute inset-0" />

          {status === "loading" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/80 text-white">
              <Camera className="size-10 animate-pulse text-primary" />
              <p className="text-sm text-white/80">Starting camera…</p>
              <p className="text-xs text-white/50">Please allow camera access</p>
            </div>
          )}

          {status === "error" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-8 text-center bg-black/90 text-white">
              <p className="text-base font-medium">{errorMsg}</p>
              <button
                className="px-4 py-2 rounded-full bg-white/15 backdrop-blur"
                onClick={() => setScreen("filters")}
              >
                Back to filters
              </button>
            </div>
          )}

          {/* Counter chip overlay */}
          <div className="absolute top-3 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-full bg-black/65 backdrop-blur text-white text-xs font-medium whitespace-nowrap">
            {scannedCodes.length === 0
              ? "Point camera at shoes"
              : matchCount > 0
                ? `${matchCount} match${matchCount === 1 ? "" : "es"} · ${scannedCodes.length} scanned`
                : `${scannedCodes.length} scanned`}
          </div>

          {/* AI identify button overlay */}
          <button
            onClick={handleIdentify}
            disabled={identifying || status !== "ready"}
            aria-label="Identify shoe with AI"
            className="absolute bottom-3 right-3 size-12 rounded-full bg-white/15 backdrop-blur-md border border-white/30 text-white flex items-center justify-center shadow-xl active:scale-95 disabled:opacity-40"
          >
            {identifying ? (
              <Loader2 className="size-5 animate-spin" />
            ) : (
              <Sparkles className="size-5 text-primary" />
            )}
          </button>
        </div>

        {/* Identification result card */}
        {identification && (
          <div className="mt-3 rounded-2xl bg-card border border-border p-4">
            <div className="flex items-start gap-3">
              <div className="size-9 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                <Sparkles className="size-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs uppercase tracking-wider text-primary/90">AI identified</p>
                  <button
                    onClick={() => setIdentification(null)}
                    aria-label="Dismiss"
                    className="size-6 rounded-full bg-secondary flex items-center justify-center"
                  >
                    <X className="size-3.5" />
                  </button>
                </div>
                <p className="font-semibold mt-0.5 truncate">{identification.id.name}</p>
                <p className="text-xs text-muted-foreground leading-snug mt-1">
                  {identification.id.summary}
                </p>
                {identification.id.features && identification.id.features.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {identification.id.features.slice(0, 4).map((f) => (
                      <span
                        key={f}
                        className="px-2 py-0.5 rounded-full bg-secondary text-[10px] font-medium"
                      >
                        {f}
                      </span>
                    ))}
                  </div>
                )}
                {identification.match && (
                  <button
                    onClick={() => {
                      addScanned(identification.match!.product_code);
                      setIdentification(null);
                      setScreen("results");
                    }}
                    className="mt-3 w-full text-left rounded-xl bg-primary/10 border border-primary/40 px-3 py-2 active:scale-[0.98] transition"
                  >
                    <p className="text-[10px] uppercase tracking-wider text-primary">
                      Closest match in store
                    </p>
                    <p className="font-medium text-sm truncate">{identification.match.name}</p>
                    <p className="text-xs text-muted-foreground">
                      CHF {effectivePrice(identification.match).toFixed(0)} · Zone{" "}
                      {identification.match.zone} · {identification.match.aisle}
                    </p>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </section>

      <div className="fixed bottom-0 inset-x-0 p-4 bg-gradient-to-t from-background via-background/95 to-transparent">
        <Button
          size="lg"
          onClick={() => setScreen("results")}
          disabled={scannedCodes.length === 0}
          className="w-full h-14 text-base font-semibold rounded-2xl gap-2"
        >
          <ListChecks className="size-5" />
          {scannedCodes.length === 0
            ? "Scan some shoes to continue"
            : `See ${matchCount > 0 ? `${matchCount} match${matchCount === 1 ? "" : "es"}` : `${scannedCodes.length} scanned`}`}
        </Button>
      </div>
    </div>
  );
}
