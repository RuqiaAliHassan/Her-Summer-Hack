import { useApp } from "@/lib/app-store";
import {
  PRODUCTS_BY_CODE,
  effectivePrice,
  gearScore,
  matchesAllFilters,
  type Product,
} from "@/lib/products";
import { GearScorePie } from "@/components/GearScorePie";
import { ArrowLeft, Camera, Package } from "lucide-react";

function ProductRow({
  product,
  dim,
  onTap,
}: {
  product: Product;
  dim?: boolean;
  onTap: () => void;
}) {
  const score = gearScore(product);
  const price = effectivePrice(product);
  const discounted = product.discount_pct > 0;
  return (
    <button
      onClick={onTap}
      className={`w-full text-left flex items-center gap-3 p-3 rounded-2xl border border-border bg-card active:scale-[0.99] transition ${
        dim ? "opacity-55" : ""
      }`}
    >
      <div className="size-12 rounded-xl bg-secondary flex items-center justify-center shrink-0">
        <Package className="size-6 text-muted-foreground" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold truncate">{product.name}</p>
        <div className="flex items-center gap-2 mt-0.5 text-xs text-muted-foreground">
          <span className="font-medium text-foreground">
            CHF {price.toFixed(0)}
            {discounted && (
              <span className="ml-1 line-through text-muted-foreground/70">
                {product.price_chf.toFixed(0)}
              </span>
            )}
          </span>
          <span>·</span>
          <span>{product.weight_g}g</span>
          <span>·</span>
          <span className="truncate">{product.brand}</span>
        </div>
      </div>
      <GearScorePie score={score} />
    </button>
  );
}

export function ResultsSheet() {
  const { scannedCodes, filters, setScreen, setProduct } = useApp();

  const scanned = scannedCodes
    .map((c) => PRODUCTS_BY_CODE.get(c))
    .filter((p): p is Product => Boolean(p));

  const matched = scanned
    .filter((p) => matchesAllFilters(p, filters))
    .sort((a, b) => gearScore(b) - gearScore(a));

  const others = scanned
    .filter((p) => !matchesAllFilters(p, filters))
    .sort((a, b) => gearScore(b) - gearScore(a));

  return (
    <div className="min-h-dvh bg-background text-foreground flex flex-col">
      <header className="sticky top-0 z-10 px-4 py-3 bg-background/95 backdrop-blur border-b border-border flex items-center gap-3">
        <button
          onClick={() => setScreen("scan")}
          className="size-10 rounded-full bg-secondary flex items-center justify-center"
          aria-label="Back to scan"
        >
          <ArrowLeft className="size-5" />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-semibold leading-tight">Scanned items</h1>
          <p className="text-xs text-muted-foreground">
            {matched.length} match{matched.length === 1 ? "" : "es"} ·{" "}
            {filters.length} filter{filters.length === 1 ? "" : "s"} · sorted by GearScore
          </p>
        </div>
        <button
          onClick={() => setScreen("scan")}
          className="h-10 px-3 rounded-full bg-secondary flex items-center gap-1.5 text-sm font-medium"
          aria-label="Resume scanning"
        >
          <Camera className="size-4" />
          Scan more
        </button>
      </header>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-2">
        {matched.length === 0 && others.length === 0 && (
          <p className="text-center text-sm text-muted-foreground py-16">
            No products scanned yet.
          </p>
        )}

        {matched.map((p) => (
          <ProductRow
            key={p.product_code}
            product={p}
            onTap={() => {
              setProduct(p);
              setScreen("detail");
            }}
          />
        ))}

        {others.length > 0 && (
          <div className="pt-4 pb-2">
            <p className="text-xs uppercase tracking-widest text-muted-foreground px-1">
              Also scanned — not matching filters
            </p>
          </div>
        )}
        {others.map((p) => (
          <ProductRow
            key={p.product_code}
            product={p}
            dim
            onTap={() => {
              setProduct(p);
              setScreen("detail");
            }}
          />
        ))}
      </div>
    </div>
  );
}
